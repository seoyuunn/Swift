import UIKit

var greeting = "Hello, swift"

print(greeting)

print(greeting)

UIImage(systemName: "star")

var sum = 0
for i in 1...10 {
    sum += i
}
print(sum)

//var greeting = "Hello, Swift"

/* 여러줄 주석
줄이 몇개든 주석이 됨 */
//multi comment
//inline comment<

dump(greeting)
 
